import ruamel.yaml as yaml
import xml.etree.ElementTree as ET
import time as time


def readYaml(file: str):
    with open(file,mode='r', encoding='utf-8') as file:
        yamlObejec = yaml.safe_load(file)
    return yamlObejec

def readXml(file: str):
    tree = ET.parse(file)
    return tree

def setTech(text: str):
    if text == "Tech I":
        return "一级科技"
    if text == "Tech II":
        return "二级科技"
    if text == "Storyline":
        return "故事线"
    if text == "Faction":
        return "势力"
    if text == "Tech":
        return "Officer"
    if text == "官员":
        return "Tech III"
    if text == "Tech":
        return "三级科技"
    if text == "Deadspace":
        return "死亡空间"
    if text == "Abyssal":
        return "深渊"
    if text == "Premium":
        return "高级"
    if text == "Limited Time":
        return "限时提供"
    if text == "Structure Factio":
        return "势力建筑"
    if text == "Structure Tech II":
        return "二级科技建筑"
    if text == "Structure Tech I":
        return "一级科技建筑"
    
def setcategory(text: str):
    if text == "Asteroid":
        return "小行星"
    if text == "Celestial":
        return "天体"
    if text == "Station":
        return "空间站"
    if text == "Material":
        return "材料"
    if text == "Commodity":
        return "常用物品"
    if text == "Planetary Commodities":
        return "行星商品"
    if text == "Accessories":
        return "附件"
    if text == "Charge":
        return "弹药"
    if text == "Module":
        return "装备"
    if text == "Ship":
        return "舰船"
    if text == "Blueprint":
        return "蓝图"
    if text == "Infrastructure Upgrades":
        return "基础设施升级件"
    if text == "Planetary Industry":
        return "行星工业"
    if text == "Drone":
        return "无人机"
    if text == "Orbitals":
        return "轨道类"
    if text == "Planetary Resources":
        return "行星资源"
    if text == "Skill":
        return "技能"
    if text == "Implant":
        return "植入体"
    if text == "Fighter":
        return "铁骑舰载机"
    if text == "Placeables":
        return "可放置物品"
    if text == "Entity":
        return "空间实体"
    if text == "Apparel":
        return "服饰"
    if text == "Starbase":
        return "母星"
    if text == "Deployable":
        return "可部署物品"
    if text == "Reaction":
        return "化学反应"
    if text == "Decryptors":
        return "解码器"
    if text == "Lights":
        return "灯光"
    if text == "Owner":
        return "拥有者"
    if text == "SKINs":
        return "涂装"
    if text == "WorldSpace":
        return "内部空间"
    if text == "Structure":
        return "建筑"
    if text == "Subsystem":
        return "子系统"
    if text == "Personalization":
        return "个性化定制"
    if text == "Abstract":
        return "抽象"
    return text

if __name__ == '__main__':

    print("输入1生成基础数据，输入其他生成位置数据：")

    choose = input()

    if choose == 1:
        print("loading base data..")
        # 基础数据
        typeIDs = readYaml('typeIDs.yaml')
        groupIDs = readYaml('groupIDs.yaml')
        metaGroups = readYaml('metaGroups.yaml')
        tree = readXml("items.xml")
        print("loaded base data: start tranlate" )
        for element in tree.getroot().findall("row"):
            typeId = int(element.get("id"))
            if typeId not in typeIDs:
                break
            typeObject = typeIDs[typeId]
            if "zh" in typeObject["name"]:
                element.set("name",typeObject["name"]["zh"])
            if "zh" in groupIDs[typeObject["groupID"]]["name"]:
                element.set("group",groupIDs[typeObject["groupID"]]["name"]["zh"])
            element.set("tech",setTech(element.get("tech")))
            element.set("category",setcategory(element.get("category")))
            if "metaGroupID" in typeObject:
                element.set("tech",metaGroups[typeObject["metaGroupID"]]["nameID"]["zh"])
        tree.write("items-zh.xml","utf-8")
        print("base data end")
    else: 
        print("loading location data")
        region = readYaml('region.yaml')
        constellation = readYaml('constellation.yaml')
        solarSystem = readYaml('solarSystem.yaml')
        station = readYaml('station.yaml')
        tree1 = readXml("locations.xml")
        print("loaded location data: start tranlate" )
        for element in tree1.getroot().findall("row"):
            if int(element.get("ri")) in region:
                element.set("r",region[int(element.get("ri"))]["name"])
            if int(element.get("ci")) in constellation:
                element.set("c",constellation[int(element.get("ci"))]["name"])
            if int(element.get("syi")) in solarSystem:
                element.set("sy",solarSystem[int(element.get("syi"))]["name"])
            if int(element.get("si")) in station:
                element.set("s",station[int(element.get("si"))]["name"])
        tree1.write("location-zh.xml","utf-8")
        print("location data end")